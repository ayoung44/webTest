package com.example.demo.dto;

import com.example.demo.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

// DTO
@AllArgsConstructor
@ToString
@Getter
@Setter
public class ArticlesForm {
    private String title;
    private String contents;

    public Article toEntity() {
        return new Article(null, title, contents);
    }
}