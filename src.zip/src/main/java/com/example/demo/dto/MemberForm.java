package com.example.demo.dto;

import com.example.demo.entity.Member;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

// DTO
// (Data Transfer Object) 계층간 데이터 교환을 하기 위해서 사용하는 객체로 로직을 가가지 않는 순수한 데이터 객체만 가진 클래스이다. (GETTER SETTER)

@AllArgsConstructor
@ToString
@Getter
@Setter
public class MemberForm {
    private String user_email;
    private String user_pw;

    public Member toEntity() {
        return new Member(null, user_email, user_pw);
    }
}