package com.example.demo.controller;

import org.springframework.ui.Model;
import com.example.demo.dto.ArticlesForm;
import com.example.demo.entity.Article;
import com.example.demo.repository.ArticlesRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@Slf4j
@Controller
public class ArticlesController {
    @Autowired // 인터페이스의 구현 객체를 알아서 생성해준다.
    private ArticlesRepository articlesRepository;

    @GetMapping("/articles/{id}")
    public String show(@PathVariable Long id, Model model) {
        log.info("id : " + id);

//        1) id조회 - db에서 해당 데이터 가져오기
//        - findById(): 특정 엔티티의 id값을 기준으로 데이터를 찾아 optional타입으로 반환
        Article articleEntity = articlesRepository.findById(id).orElse(null);
//        2) articleEntity에 담긴 데이터를 모델에 등록
        model.addAttribute("article", articleEntity);

//        3) 조회한 데이터 -> 사용자에게 보여 주기 위한 뷰 페이지 생성 및 반환

//        return "articles/show";
        return "/articles/show";
    }


    @GetMapping("/articles/new")
    public String newArticleForm() {
        return "articles/new";
    }
    @PostMapping("/articles/create")
    public String createArticle(ArticlesForm form) {
        // 폼 데이터를 dto로 받기(매개변수)
        // System.out.println(form.toString());
        log.info(form.toString());

        // dto를 엔티티로 변환
        Article article = form.toEntity();
        // System.out.println(article.toString();
        log.info(article.toString());

        // 엔티티를 db에 저장 / article엔티디를 저장해 saved객체에 반환
        Article saved = articlesRepository.save(article);
        // System.out.println(saved.toString());
        log.info(saved.toString());

        // return "/articles/create";
        return "redirect:/articles/" + saved.getId();
    }
    @GetMapping("/articles")
    public String index(Model model) {
        List<Article> articleEntityList = articlesRepository.findAll();
        model.addAttribute("articleList", articleEntityList);
        return "articles/index";
    }

    @GetMapping("/articles/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
        // db에서 수정할 데이터 가져오기
        Article articleEntity = articlesRepository.findById(id).orElse(null);
        model.addAttribute("article", articleEntity);
        return "articles/edit";
    }
}

