package com.example.demo.repository;

import com.example.demo.entity.Article;
import com.example.demo.entity.Member;
import org.springframework.data.repository.CrudRepository;
import java.util.ArrayList;


public interface ArticlesRepository extends CrudRepository<Article, Long> {
    ArrayList<Article> findAll();
//    Generate → Overrid Methods 클릭  → findAll():iterable<T> 선택 → [OK] )
}
